# Project-Box-Templates

Based on video: https://youtu.be/lBK0UBjVrYM

Viewers of my channel can contribute adabtable project boxes for other CAD tools
